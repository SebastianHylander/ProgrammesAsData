## The solutions to the different exercises can be found as followed:

### 7.1
There is not really any result of doing this

### 7.2
Our programs can be found in:
 - arrsum.c
 - squares.c
 - histogram.c

### 7.3
Our solution can be found in:
 - CLex.fsl
 - CPar.fsy

And the programs from 7.2 have been changed to use forloop which can be seen in the same files as before

### 7.4, 7.5
Our solution can be found in:
 - Absyn.fs
 - CLex.fsl
 - CPar.fsy
 - Interp.fs

 A test-file for both the for-loop and PreInc can be found in 
  - forloopTest.c